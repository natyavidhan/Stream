import os

filename = os.path.join(os.path.dirname(__file__), "static\\user.png")
print(filename)